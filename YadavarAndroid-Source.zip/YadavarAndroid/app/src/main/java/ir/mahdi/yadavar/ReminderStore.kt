package ir.mahdi.yadavar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ReminderStore {
    private const val PREFS = "reminders"
    private const val KEY = "items"

    fun all(context: Context): MutableList<Reminder> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val result = mutableListOf<Reminder>()
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(Reminder(o.getInt("id"), o.getString("title"), o.getLong("time")))
            }
        } catch (_: Exception) { }
        return result.sortedBy { it.time }.toMutableList()
    }

    fun save(context: Context, items: List<Reminder>) {
        val array = JSONArray()
        items.forEach {
            array.put(JSONObject().put("id", it.id).put("title", it.title).put("time", it.time))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }
}
