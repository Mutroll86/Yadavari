package ir.mahdi.yadavar

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private val fa = Locale("fa", "IR")
    private val displayFormat = SimpleDateFormat("yyyy/MM/dd  HH:mm", fa)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        requestPermissionsIfNeeded()
        buildScreen()
        refreshList()
        askExactAlarmPermissionIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun askExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { }
            }
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF6F7FB.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "یادآور من"
            textSize = 28f
            setTextColor(0xFF172554.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(header)
        val subtitle = TextView(this).apply {
            text = "برنامه‌هایت را ثبت کن؛ سر وقت به تو یادآوری می‌کنم."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF64748B.toInt())
            setPadding(0, 0, 0, 24)
        }
        root.addView(subtitle)

        val titleInput = EditText(this).apply {
            hint = "موضوع برنامه؛ مثلاً مطالعه شبکه"
            textSize = 16f
            singleLine = true
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(titleInput, matchWrap())

        var selectedTime = Calendar.getInstance().apply { add(Calendar.MINUTE, 10); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val timeButton = Button(this).apply { text = "زمان: " + displayFormat.format(selectedTime.time) }
        root.addView(timeButton, matchWrap())
        timeButton.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                TimePickerDialog(this, { _, hour, minute ->
                    selectedTime.set(year, month, day, hour, minute, 0)
                    selectedTime.set(Calendar.MILLISECOND, 0)
                    timeButton.text = "زمان: " + displayFormat.format(selectedTime.time)
                }, selectedTime.get(Calendar.HOUR_OF_DAY), selectedTime.get(Calendar.MINUTE), true).show()
            }, selectedTime.get(Calendar.YEAR), selectedTime.get(Calendar.MONTH), selectedTime.get(Calendar.DAY_OF_MONTH)).show()
        }

        val addButton = Button(this).apply {
            text = "＋ ثبت یادآور"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF2563EB.toInt())
        }
        root.addView(addButton, matchWrap())
        addButton.setOnClickListener {
            val title = titleInput.text.toString().trim()
            if (title.isEmpty()) {
                titleInput.error = "موضوع را وارد کن"
                return@setOnClickListener
            }
            if (selectedTime.timeInMillis <= System.currentTimeMillis()) {
                Toast.makeText(this, "زمان باید در آینده باشد.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val items = ReminderStore.all(this)
            val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
            val reminder = Reminder(id, title, selectedTime.timeInMillis)
            items.add(reminder)
            ReminderStore.save(this, items)
            AlarmScheduler.schedule(this, reminder)
            titleInput.text.clear()
            Toast.makeText(this, "یادآور ثبت شد.", Toast.LENGTH_SHORT).show()
            refreshList()
        }

        val section = TextView(this).apply {
            text = "یادآورهای ثبت‌شده"
            textSize = 20f
            setTextColor(0xFF172554.toInt())
            setPadding(0, 28, 0, 12)
        }
        root.addView(section)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox, matchWrap())
        val foot = TextView(this).apply {
            text = "این برنامه آفلاین است. برای آلارم دقیق، مجوز آلارم و اعلان را فعال نگه دار."
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
            setPadding(4, 24, 4, 8)
        }
        root.addView(foot)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun refreshList() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val items = ReminderStore.all(this)
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "هنوز یادآوری ثبت نکرده‌ای."
                textSize = 14f
                setTextColor(0xFF64748B.toInt())
                setPadding(8, 12, 8, 12)
            })
            return
        }
        items.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = item.title
                textSize = 17f
                setTextColor(0xFF0F172A.toInt())
            })
            card.addView(TextView(this).apply {
                text = displayFormat.format(Date(item.time))
                textSize = 13f
                setTextColor(0xFF64748B.toInt())
                setPadding(0, 4, 0, 4)
            })
            val delete = Button(this).apply { text = "حذف یادآور" }
            delete.setOnClickListener {
                AlarmScheduler.cancel(this, item)
                val updated = ReminderStore.all(this).filterNot { it.id == item.id }
                ReminderStore.save(this, updated)
                refreshList()
            }
            card.addView(delete)
            val params = matchWrap().apply { bottomMargin = 10 }
            listBox.addView(card, params)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::listBox.isInitialized) refreshList()
    }
}
