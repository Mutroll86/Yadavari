package ir.mahdi.yadavar

data class Reminder(val id: Int, val title: String, val time: Long)
